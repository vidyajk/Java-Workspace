package com.lti.training.day3.abstraction;

public class TestLogger {
   
	public static void main(String[] args) {
		Logger logger= new Logger();
		logger.log("happy msg");
		logger.log("some concern to be addressed",LogLevel.WARN);
	  logger.log("some critical msg", LogLevel.ERROR);
	}
}
