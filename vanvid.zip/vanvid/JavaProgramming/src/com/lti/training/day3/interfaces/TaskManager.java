package com.lti.training.day3.interfaces;

public class TaskManager 
{
	private MobileApplication[ ] runningApps;
	private int count;
	
public TaskManager()
{
	runningApps= new MobileApplication[100];
	
}
public void newAppLoaded(MobileApplication mobileApp) {
	runningApps[count++]= mobileApp;
	
}
public int getNumberOfRunningApps() {
	return count;
}
public void closeAllRunningApps() {
	for(int i=0;i<count;i++)
		runningApps[i].stop();
	count=0;
}
}
