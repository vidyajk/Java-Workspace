package com.lti.training.day3.abstraction.v5;

public interface Logger
{
//from java8 onwards
	//interface can be non-abstract and static methods as well
	
	public  default  void log(String msg)
	{
 log(msg, LogLevel.INFO);
		
}
	public  void log(String msg,LogLevel level);
	}
