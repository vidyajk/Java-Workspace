package com.lti.training.day3.abstraction;

public enum LogLevel 
{
    INFO, WARN, ERROR;
}
