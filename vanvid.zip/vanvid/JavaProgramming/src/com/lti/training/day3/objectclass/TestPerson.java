package com.lti.training.day3.objectclass;

public class TestPerson
{
	public static void main(String[] args) throws CloneNotSupportedException 
	{
	Person p1 = new Person();
	p1.setAge(45);
p1.setName("vanvid");
System.out.println(p1.getName()+" "+p1.getAge());
System.out.println(p1);
 Person p2 = new Person("vanvid",45);
System.out.println(p1 == p2);   // reference comparison
System.out.println(p1.equals(p2));
System.out.println(p1.hashCode());
System.out.println(p2.hashCode());
	Person p3=(Person)p1.clone();
	//Person p3=new Person(p1.getName() ,p1.getAge());---------------getting the copy of the object without using clone()
	Person p4 = new Person();
	p4.setName("abc");
	p4.setAge(56);
	Address ad = new Address("bangalore","karnataka",900090);
	p4.setAddress(ad);
	System.out.println("the city where the"+p4.getName()+"lives is"+p4.getAddress().getCity());
	Person p5 =(Person)p4.clone();
	/*System.out.println(p5.getAddress());
	p4.getAddress().setCity("bang");*/
	System.out.println();
	p4.getAddress().setCity("Mysore");
	System.out.println("the city where the"+p4.getName()+"lives is"+p4.getAddress().getCity());
	System.out.println(p5.getAddress());//this will print the original data not the mysore coz of deep cloning
	p1=null;
	p2=null;
	System.gc();
	}

}
