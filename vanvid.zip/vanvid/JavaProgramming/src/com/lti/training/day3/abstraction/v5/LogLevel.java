package com.lti.training.day3.abstraction.v5;

public enum LogLevel 
{
    INFO, WARN, ERROR;
}
