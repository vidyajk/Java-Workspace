package com.lti.training.day3.interfaces;

public class MyMoblieApplication1  implements MobileApplication {

	@Override
	public void start() 
	{

		  System.out.println("MyMobileApplication1 started");
	}

	@Override
	public void pause()
	{
		System.out.println("MyMobileApplication1 paused.");
		
	}

	@Override
	public void stop()
	{
		System.out.println("MyMobileApplication1 stopped.");

	
		
	}
	

}
