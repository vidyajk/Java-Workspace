package com.lti.training.day3.abstraction.v2;

public class Logger
{

	public void log(String msg)
	{
 log(msg, LogLevel.INFO);
		
}
	public void log(String msg,LogLevel level)
	{
	}
	}
