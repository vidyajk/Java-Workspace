package com.lti.training.day3.interfaces;

public class MyMoblieApplication2  implements MobileApplication {

	@Override
	public void start() 
	{

		  System.out.println("MyMobileApplication2 started");
	}

	@Override
	public void pause()
	{
		System.out.println("MyMobileApplication2 paused.");
		
	}

	@Override
	public void stop()
	{
		System.out.println("MyMobileApplication2 stopped.");

	
		
	}
	

}
