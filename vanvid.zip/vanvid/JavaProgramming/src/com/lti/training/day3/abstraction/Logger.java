package com.lti.training.day3.abstraction;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * a simple implementation of logger in java
 * 
 * @author vanvid
 *@version 1.0
 *
 */
public class Logger 
{
	public void log(String msg) {
		System.out.println("[INFO] ["+LocalDateTime.now()+"]" + " " +msg);

		
	}
public void log(String msg,LogLevel level)
   {
	 switch(level) 
	 {
	 case INFO:
		        System.out.println("[INFO] ["+LocalDateTime.now()+"]" + " " +msg);
		        break;
	 case WARN:       
		        System.out.println("[WARN ["+LocalDateTime.now()+"]" + " " +msg);
		        break;
	 case ERROR:
	        System.out.println("[ERROR] ["+LocalDateTime.now()+"]" + " " +msg);
	     
	 }
         	
    }

}
