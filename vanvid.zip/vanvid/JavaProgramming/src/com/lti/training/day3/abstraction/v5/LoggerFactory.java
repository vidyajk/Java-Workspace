package com.lti.training.day3.abstraction.v5;

//factory design pattern
public class LoggerFactory 
{
public static Logger getLoggerInstance()
{
return new Console_Logger();

}
}
