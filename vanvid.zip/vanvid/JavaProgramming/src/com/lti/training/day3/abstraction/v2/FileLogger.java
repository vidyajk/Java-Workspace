package com.lti.training.day3.abstraction.v2;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * a simple implementation of logger in java
 * 
 * @author vanvid
 *@version 1.0
 *
 */
public class FileLogger extends Logger
{
	@Override
public void log(String msg,LogLevel level)
   {
	try(FileWriter fw= new FileWriter("app.log",true)) {
	 switch(level) 
	 {
	 case INFO:
		       fw.write("[INFO] ["+LocalDateTime.now()+"]" + " " +msg+"\n");
		        break;
	 case WARN:       
		    fw.write("[WARN ["+LocalDateTime.now()+"]" + " " +msg+"\n");
		        break;
	 case ERROR:
	     fw.write("[ERROR] ["+LocalDateTime.now()+"]" + " " +msg);
	     
	 }
         	
    }
	catch(IOException e)
	{
		e.printStackTrace();
	}
   }
}
