package com.lti.training.day3.abstraction.v3;

public enum LogLevel 
{
    INFO, WARN, ERROR;
}
