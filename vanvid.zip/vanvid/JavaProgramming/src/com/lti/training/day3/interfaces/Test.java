package com.lti.training.day3.interfaces;

public class Test 
{
	public static void main(String[] args)
	{
		
     MyMoblieApplication1 app1=new MyMoblieApplication1();
      MyMoblieApplication2 app2=new MyMoblieApplication2();
Launcher launcher = new Launcher();
launcher.launch(app1);
launcher.launch(app2);
System.out.println(launcher.runningAppsCount());
launcher.closeAllApps();

	}
}