package com.lti.training.day3.abstraction.v4;

import java.io.FileWriter;

public class TestLogger {
   
	public static void main(String[] args) {
	//Console_Logger logger= new Console_Logger();
		//FileLogger logger= new FileLogger();
	//	Logger logger = new FileLogger();
		Logger logger=LoggerFactory.getLoggerInstance();
		logger.log("happy msg");
	 logger.log("some concern to be addressed",LogLevel.WARN);
	  logger.log("some critical msg", LogLevel.ERROR);
	}
}
