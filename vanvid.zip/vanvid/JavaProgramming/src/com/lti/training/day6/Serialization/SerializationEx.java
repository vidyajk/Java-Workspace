package com.lti.training.day6.Serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializationEx {
	
	private static void serialize() throws Exception {
		
		FileOutputStream f = new FileOutputStream("emp.txt");
		ObjectOutputStream os = new ObjectOutputStream(f);
		
		Emp e = new Emp();
		e.setEmpno(1001);
		e.setName("vanaja");
		e.setSalary(10000);
		
		os.writeObject(e);//serialization --- saving state of an object
		os.close();
		f.close();
	}

	private static void deserialize() throws Exception
	{
	FileInputStream f = new FileInputStream("emp.txt");
	ObjectInputStream os= new ObjectInputStream(f);
	Emp e = (Emp) os.readObject();
	System.out.println(e.getEmpno());
	System.out.println(e.getName());
	System.out.println(e.getSalary());
	os.close();
f.close();
} 
	
	public static void main(String[] args) throws Exception {
		serialize();
		deserialize();
	}
}
