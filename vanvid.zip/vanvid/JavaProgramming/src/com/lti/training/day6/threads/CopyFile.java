package com.lti.training.day6.threads;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
public class CopyFile {
	public static void main(String[] args)
	{
		FileInputStream infile = null;
		FileOutputStream outfile=null;
		//FileReader infile = null;
	//	FileWriter outfile = null;
		try 
		{

			infile = new FileInputStream("D:\\jdk-8u131-windows-x64.exe");
			outfile = new FileOutputStream("D:\\jdk2.exe");
			
	//infile = new FileReader("C:\\Users\\vshadmin\\Downloads\\photo1.jpg");	//corrupted
	//outfile = new FileWriter("C:\\Users\\vshadmin\\Downloads\\photo2.jpg");//corrupted

	int ch=0;
	while(true)
	{
		ch = infile.read();
		if(ch==-1)//eof
	break;
		outfile.write(ch);
	}
	System.out.println("file copied successfully");
		}
		catch(FileNotFoundException e)
		{
			System.out.println("plz check the no of ur glasses");
		}
		catch(IOException e)
		{
			System.out.println("plz contact technical group");
		}
		finally
		{
			try {
				infile.close();
				outfile.close();
			}
			catch(Exception e) 
			{
			}
		}
	}
			}


