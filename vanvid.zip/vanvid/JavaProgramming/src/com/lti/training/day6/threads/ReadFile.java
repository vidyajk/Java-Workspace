package com.lti.training.day6.threads;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ReadFile 
{
public static void main(String[] args)
{
	FileInputStream infile = null;
	try 
	{
infile = new FileInputStream("sample.txt");
int ch=0;
while(true)
{
	ch = infile.read();
	if(ch==-1)//eof
break;
	System.out.print((char)ch);
}
	}
	catch(FileNotFoundException e)
	{
		System.out.println("plz check the no of ur glasses");
	}
	catch(IOException e)
	{
		System.out.println("plz contact technical group");
	}
	finally
	{
		try {
			infile.close();
		}
		catch(Exception e) 
		{
		}
	}
}
		}
