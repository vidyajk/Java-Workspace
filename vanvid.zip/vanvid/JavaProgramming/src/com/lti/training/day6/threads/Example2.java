package com.lti.training.day6.threads;

public class Example2
{
	class SomeTask implements Runnable
	{

		@Override
		public void run() {
System.out.println("line 1 executed..");
try {
	Thread.sleep(1000*60*60);
}
catch(InterruptedException e)
{
	System.out.println("who woke me up");
}
System.out.println("line2 excecuted..");
		}
		
	}
	void launch()
	{
		Thread th = new Thread(new SomeTask());
		th.start();
		try
		{
			Thread th1 = new Thread(new SomeTask());
			th1.start();
			try {
				Thread.sleep(5000);
			}
			catch(Exception e)
			{
		
			}
			th1.interrupt();
		
	}
	}
	public static void main(String[] args) {
		new Example2().launch();
	
}
