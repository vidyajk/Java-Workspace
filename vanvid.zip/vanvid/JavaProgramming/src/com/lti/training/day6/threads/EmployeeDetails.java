package com.lti.training.day6.threads;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class EmployeeDetails 
{
	FileReader infile = null;
	FileWriter outfile=null;
	BufferedReader inbuffer= null;//the default size of buffer is 8kb
	BufferedWriter outbuffer = null;
	try 
	{

		infile = new FileReader("emp.csv");
		
		outfile = new FileWriter("Sample2.txt");
		inbuffer = new BufferedReader(infile,1024*16);
		outbuffer = new BufferedWriter(outfile,1024*16);
		for(int j=1;j<=files;j++)
		String str = null;
		for(int i=i+1;i<=(j*lines);i++)
		str = 
		while(true)
		{
		line = inbuffer.readLine().toUpperCase();
			if(line == null)//eof
		break;
			
			outbuffer.write(line);
			outbuffer.newLine();
		}
		System.out.println("file copied successfully");
			}
			catch(FileNotFoundException e)
			{
				System.out.println("plz check the no of ur glasses");
			}
			catch(IOException e)
			{
				System.out.println("plz contact technical group");
			}
			finally
			{
				try {
					inbuffer.close();
					
					infile.close();
					outbuffer.close();
					outfile.close();
				}
				catch(Exception e) 
				{
				}
			}
		

}
