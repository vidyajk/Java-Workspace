package com.lti.training.day6.threads;

class BankAccount{
	
	int acno;
	double balance;
	
	public BankAccount(int acno, double balance) {
		super();
		this.acno = acno;
		this.balance = balance;
	}
	
	public  synchronized void withdraw(double amount) {
		try {Thread.sleep(100);} catch (Exception e) {}
		if(amount < balance) {
			try {Thread.sleep(100);} catch (Exception e) {}
		balance -= amount;
		try {Thread.sleep(100);} catch (Exception e) {}
		System.out.println("balance left" + balance);
		
		}
		else
			System.out.println("insufficient balance");
	}

}


class Transaction implements Runnable{
	
	BankAccount bankAccount;
	
	public Transaction(BankAccount bankAccount) {
		super();
		this.bankAccount = bankAccount;
	}

	@Override
	public void run() {
	
bankAccount.withdraw(5000);		
	}
}

public class Example3 {
 public static void main(String[] args) {
	
	 BankAccount bankAcc = new BankAccount(1111,8000);
	 Transaction tx1 = new Transaction(bankAcc);
	 Transaction tx2 = new Transaction(bankAcc);
Thread th1 = new Thread(tx1);
Thread th2 = new Thread(tx2); 
th1.start();
 th2.start();
 }
}
