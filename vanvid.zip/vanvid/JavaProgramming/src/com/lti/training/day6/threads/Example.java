package com.lti.training.day6.threads;

import com.lti.training.day6.threads.Example.Task;

public class Example 
{
//inner classes
	class  Task implements Runnable{

	@Override
	public void run() {
		
		for(int i=0;i<100000;i++) {
			System.out.println("task running");
	//		try { Thread.sleep(100);} catch(InterruptedException e) {}
			Thread.yield();
	}
		
	}
}

class Task1 implements Runnable{

	@Override
	public void run() {
	
			for(int i=0;i<100000;i++) {
				System.out.println("task1  running");
			//	try { Thread.sleep(100);} catch(InterruptedException e) {}	
			Thread.yield();
	}
	}
}


private void launch() {
	Task  task = new Task();
	Task1  task1 = new Task1();
	Thread th =new Thread(task);
	Thread th1 =new Thread(task1);
	th.setPriority(Thread.MIN_PRIORITY);
	th1.setPriority(Thread.MAX_PRIORITY);
	//th.setDaemon(true);
	//th1.setDaemon(true);
	th.start();
	th1.start();
	
}
public static void main(String[] args) {
	new Example().launch();
}
}