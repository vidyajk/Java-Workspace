package com.lti.training.day6.threads;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class CopyFile23 {
	public static void main(String[] args)
	{
		FileReader infile = null;
		FileWriter outfile=null;
		BufferedReader inbuffer= null;//the default size of buffer is 8kb
		BufferedWriter outbuffer = null;
		try 
		{

			infile = new FileReader("Sample.txt");
			outfile = new FileWriter("Sample2.txt");
			inbuffer = new BufferedReader(infile,1024*16);
			outbuffer = new BufferedWriter(outfile,1024*16);
			

	String line=null;
	while(true)
	{
	line = inbuffer.readLine().toUpperCase();
		if(line == null)//eof
	break;
		
		outbuffer.write(line);
		outbuffer.newLine();
	}
	System.out.println("file copied successfully");
		}
		catch(FileNotFoundException e)
		{
			System.out.println("plz check the no of ur glasses");
		}
		catch(IOException e)
		{
			System.out.println("plz contact technical group");
		}
		finally
		{
			try {
				inbuffer.close();
				
				infile.close();
				outbuffer.close();
				outfile.close();
			}
			catch(Exception e) 
			{
			}
		}
	}
			}


