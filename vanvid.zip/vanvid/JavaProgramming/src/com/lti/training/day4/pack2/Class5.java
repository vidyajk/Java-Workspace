package com.lti.training.day4.pack2;

import com.lti.training.day4.pack1.Class1;

public class Class5  
{

void check()
{
	Class1 c1 = new Class1();
	System.out.println(c1.a);
	System.out.println(c1.b);
	System.out.println(c1.c);
	System.out.println(c1.d);
}

}