package com.lti.training.day4.abstraction.collections;

import java.util.ArrayList;
import java.util.List;

public class UserManager 
{

	private List<User>  users;

	public UserManager()
	{
       users = new ArrayList<User>();
       users.add(new User("van","123"));
       users.add(new User("vid","321"));
       users.add(new User("ram","183"));
       users.add(new User("lak","923"));
	}	
	public boolean isValidUser(String username, String password)
	{
	for(User use : users)
	{
	if(use.getUsername().equals(username) && use.getPassword().equals(password));
	return true;
	}
	return false;
}
		
	
	public static void main(String[] args) {
		UserManager userManager = new UserManager();
		boolean isValid = userManager.isValidUser("van", "103");
		System.out.println(isValid);
		
	}
}
