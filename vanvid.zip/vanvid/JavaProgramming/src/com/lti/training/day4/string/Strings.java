package com.lti.training.day4.string;

public class Strings {
	public static void main(String[] args) {
		
		String s1="java";
		String s2="java";
		String s3= new String ("java");
		String s4= new String ("java");
		
		System.out.println(s1==s2);
		System.out.println(s3==s4);
		String s5= "JAVA";
		String s6 = s1.toUpperCase().intern();
		System.out.println(s5==s6);

		String s7 ="hello";
		String s8 ="world";
		String s9 ="helloworld";
		String s10 =s7 + s8;
		System.out.println(s9 == s10);
		
		// string concatenation is most expensive
		String str = "fwq5t4rerewqyuie65243483205=03krkjg@!#$%^&*(bdheweprolewkrkf=rreljjy78r5r3h2";
		String newstr = " ";
		long abc = System.nanoTime();
		for(int i=0; i<str.length();i++)
			for(int j=0;j<=i;j++)
				newstr=newstr +str.charAt(j);
		long abc1 = System.nanoTime();

	
		System.out.println(newstr);
		System.out.println("app. tym taken "  + (abc1-abc) + "  ns");
		
		//using string buffer = = much faster then string concatenation
		
		StringBuffer buffer = new StringBuffer();
		 abc = System.nanoTime();
		for(int i=0; i<str.length();i++)
			for(int j=0;j<=i;j++)
				buffer.append(str.charAt(j));
		abc1 = System.nanoTime();

		System.out.println(buffer);
		System.out.println("app. tym taken "  + (abc1-abc) + "  ns");
		
		
		//using string builder == much faster then stringbuffer
		
				StringBuilder builder = new StringBuilder();
				 abc = System.nanoTime();
				for(int i=0; i<str.length();i++)
					for(int j=0;j<=i;j++)
						builder.append(str.charAt(j));
				abc1 = System.nanoTime();

				System.out.println(builder);
				System.out.println("app. tym taken "  + (abc1-abc) + "  ns");

	}

}
