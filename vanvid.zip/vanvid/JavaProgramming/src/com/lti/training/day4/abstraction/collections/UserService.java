package com.lti.training.day4.abstraction.collections;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserService
{
	private Map<String , String > users;

	public UserService()
	{
       users = new HashMap<>();
       users.put("vid", "123");
       users.put("van", "414");
       users.put("asm", "897");
       users.put("gty", "768");
	}	
	public boolean isValidUser(String username, String password)
	{
	if(users.containsKey(username))
	{
		String pwd = users.get(username);
		if(pwd.equals(password))
			return true;
	}
	return false;
	}
		
	
	public static void main(String[] args) {
		UserManager userManager = new UserManager();
		boolean isValid = userManager.isValidUser("van", "103");
		System.out.println(isValid);
		
	}
}



