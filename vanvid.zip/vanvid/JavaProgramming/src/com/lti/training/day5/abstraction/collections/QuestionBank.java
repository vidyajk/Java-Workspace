package com.lti.training.day5.abstraction.collections;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QuestionBank {

	private Map<String, List<Questions>> questionBank;
	
	public QuestionBank()
	{
		questionBank = new HashMap<>();
	}
	
	public void addNewSubject(String subject)
	{
		questionBank.put(subject, new ArrayList<>());
	}
	
	public void addNewQuestion(String subject, Questions question) 
	{
	List<Questions> questions = questionBank.get(subject) ;
	questions.add(question);
	
	}
	public List<Questions> getQuestionsFor(String subject)
	{
		return questionBank.get(subject);
	}
}
