package com.lti.training.day5.wrapperclass;

public class WrapperClassExample {
public static void main(String[] args) {
	int x=10;
	
	Integer y=20; // called as autoboxing in modren tech. 
	//the above line is equivqlent to
	Integer z= new Integer(30);
	
/*	int a=10;
	a=20;
	
	Integer b=10;// new obj is created
	b=20;// new object is created again*/
	//converting int to Integer
	Integer e=10;// new Integer(10);
	//converting Integer to int
	int f=e;//e.intValue();
	//coverting String to Integer
	Integer g=new Integer("100");
	//coverting Integer to String
	String h= g.toString();
	//converting String to int
	int i= Integer.parseInt("100");
	//converting int to String
	String j=Integer.toString(100);
	//todo: int->String->primitive float->wrapper Double->Integer
	 
	int a=123;
	String ab = Integer.toString(a);
	 
	float bc = Float.parseFloat("ab");
	
	Double cd = new Double(bc);	
	
	Integer de = Double.pa
}

}
