package com.lti.training.day5.wrapperclass;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.lti.training.day3.objectclass.Person;

public class ExampleOnList 
{
public static void main(String[] args)
{
	List<String> list1 = new ArrayList<>();
	list1.add("java");
	list1.add("Oracle");
	list1.add(".net");
	list1.add("php");
	list1.add("java");
	
	List<String> list2 = new ArrayList<>();
	list2.add("java1");
	list2.add("Oracle1");
	list2.add(".net1");
	list2.add("php1");
	list2.add("java1");
	
	/*System.out.println("option 1: old fashioned for loop");
	for(int i=0;i<list1.size();i++)
		System.out.println(list1.get(i));
	
	System.out.println("option 2: using for-each loop");
	for(String str: list1)
		System.out.println(str);
	

	System.out.println("option 3: java8 lambda style for-each ");
	list1.forEach(str-> System.out.println(str));
	
	System.out.println("option4: traditional iterator");
	Iterator<String> itr = list1.iterator();
	while(itr.hasNext())
		System.out.println(itr.next());

	List<Person> list2 = new ArrayList<>();
  list2.add(new Person("vid", 100));
	list2.add(new Person("van", 16));
	for(Person p : list2 )
		System.out.println(p);*/
	
	list1.add(2,"d element");
	list1.addAll(list2);
	list1.isEmpty();
	System.out.println(list1);
}
}
