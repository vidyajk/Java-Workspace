package com.lti.training.day5.abstraction.collections;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class QuestionBankLoader
{
	private QuestionBank questionBank;
	
	
public QuestionBankLoader() {
	questionBank = new QuestionBank();
	
}

public void loadQuestionsOnJava()
{
	
	questionBank.addNewSubject("JAVA");
	Questions q = new Questions();
	q.setQuestion("what is class");
	List<Option> options = new ArrayList<>();
	Option o1 = new Option("class is a template", true);
	Option o2 = new Option("class is a classroom",false);
	Option o3 = new Option("class is a datatype",false);
	Option o4 = new Option("class is class",false);
	options.add(o1);
	options.add(o2);
	options.add(o3);
	options.add(o4);
	q.setOptions(options);
	questionBank.addNewQuestion("Java", q);
	
	q.setQuestion("what is Object");
	List<Option> options1 = new ArrayList<>();
	Option o5 = new Option("Object is a instance of class", true);
	Option o6 = new Option("obj is a classroom",false);
	Option o7 = new Option("obj is a datatype",false);
	Option o8 = new Option("obj is class",false);
	options1.add(o5);
	options1.add(o6);
	options1.add(o7);
	options1.add(o8);
	q.setOptions(options1);
	questionBank.addNewQuestion("Java", q);
	
	q.setQuestion("what is G1?");
	List<Option> options2 = new ArrayList<>();
	Option o9 = new Option("G1 is garbage collector", true);
	Option o10 = new Option("G1 is a classroom",false);
	Option o11 = new Option("G1 is a datatype",false);
	Option o12 = new Option("G1 is class",false);
	options2.add(o9);
	options2.add(o10);
	options2.add(o11);
	options2.add(o12);
	q.setOptions(options2);
	questionBank.addNewQuestion("Java", q);
	

}

public void startExam()
{
	Scanner sc = new Scanner(System.in);
	int score =0;
	
	List<Questions> questions = questionBank.getQuestionsFor("java");
	for(Questions question : questions)
	{
	System.out.println("Q"+question.getQuestion());
	for(Option option : question.getOptions())
	System.out.println(option.getOption());
	System.out.println("enter the right answer(1-4)");
	int ans = sc.nextInt();
	 Option selectedOption = question.getOptions().get(ans-1);
	 if(selectedOption.isRightAnswer())
		 score++;
	}
	System.out.println("\n\n you have scored"+score+"/3");
}

public static void main(String[] args) {
	
	QuestionBankLoader qbl = new QuestionBankLoader();
	qbl.loadQuestionsOnJava();
	qbl.startExam();
}

}
