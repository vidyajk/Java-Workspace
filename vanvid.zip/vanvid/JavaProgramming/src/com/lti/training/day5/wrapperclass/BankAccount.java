package com.lti.training.day5.wrapperclass;

public class BankAccount {
	
	private int acno;
	private String name;
	private double balance;

public BankAccount(int acno, String name, double balance) {
		super();
		this.acno = acno;
		this.name = name;
		this.balance = balance;
	}
	public double withdraw(double amount) throws AccountException
	{
		if(amount > balance)
			
	{
			AccountException e = new AccountException("insufficient Balance!!");
	throw e;		
	}
		else
		{
			balance = amount;
			return balance;
		}
	}
	public static void main(String[] args) 
	{
		BankAccount bc = new BankAccount(1001,"vid", 5000);
		try
		{
			double balance = bc.withdraw(4560);
			System.out.println("balance left" + balance);
		}
		catch(AccountException e)
		{
			//System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
	}


