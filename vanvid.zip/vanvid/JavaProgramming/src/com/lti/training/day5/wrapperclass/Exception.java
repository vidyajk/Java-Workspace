package com.lti.training.day5.wrapperclass;

public class Exception1 
{
private int acno;
private String name;
private double balance;



public Exception(int acno, String name, double balance) {
	super();
	this.acno = acno;
	this.name = name;
	this.balance = balance;
}

public double withdraw(double amount) throws Exception
{
	if(amount > balance)
		
{
		Exception e = new Exception("insufficient Balane!!");
throw e;		
}
	else
	{
		balance = amount;
		return balance;
	}
}
public static void main(String[] args) 
{
	BankAccount bc = new BankAccount(1001,"vid", 5000);
	try
	{
		double balance = bc.withdraw(4560);
		System.out.println("balance left" + balance);
	}
	catch(Exception e)
	{
		System.out.println(e.getMessage());
	}
}
}
