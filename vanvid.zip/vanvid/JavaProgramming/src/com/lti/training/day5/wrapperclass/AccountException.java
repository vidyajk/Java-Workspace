package com.lti.training.day5.wrapperclass;

public class AccountException extends Exception 
{
public AccountException(String msg) {
	super(msg);  
}
}
