package com.lti.training.day2.basics;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.Scanner;

public class Age 
{
public static void main(String[] args) 
{
	Scanner sc = new Scanner(System.in);
	System.out.println("enter ur date of birth in dd-mm-yyyy");
	String a=sc.next();
 SimpleDateFormat d1 = new SimpleDateFormat("dd/MM/yyyy");
 Date d2=d1.parse(a);
 int birthyear=d2.getYear();
 Date currentdate = new Date();
 int currentyear = currentdate.getYear();
 System.out.println("your age is"+(currentyear - birthyear));
}
}