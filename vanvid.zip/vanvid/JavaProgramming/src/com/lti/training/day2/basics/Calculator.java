package com.lti.training.day2.basics;

public class Calculator
{
public void add(int x,int y)
{
	System.out.println(x+y);
}
public void sub(int x,int y)
{
	System.out.println(x-y);
}
public static void main(String[] args) 
{
	Calculator c= new Calculator();
	c.add(10,56);
	c.sub(76, 56);
}
}
