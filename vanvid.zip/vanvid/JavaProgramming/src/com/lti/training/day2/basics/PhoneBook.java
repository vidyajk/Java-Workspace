package com.lti.training.day2.basics;

public class PhoneBook
{
	private Contact[ ] contacts;
	private int count=0;
	//default constructors
	public PhoneBook()
	{
		contacts =new Contact[100];
	}
		//parameterized constructor
			public PhoneBook(int noOfEnteries)
{
				contacts= new Contact[noOfEnteries];
}
public void add(Contact contact)
{
	
 contacts[count++] = contact;

	
}
	public Contact searchByName(String name)
	{
		for(int i=0;i<count;i++)
		
			if(contacts[i].getName()==name)
			return contacts[i];
			return null;
		
	}
	public Contact searchByNumber(String number)
	{
		  
		}
public void clear()
	{
		
	}
public void display()
{
	for(int i=0;i<count;i++)
	{
		System.out.println(contacts[i].getName()+"\t"
				+contacts[i].getNumber()+"\t"
				+contacts[i].getEmail()+"\t"
				+contacts[i].getDob());
	}
	}
}

