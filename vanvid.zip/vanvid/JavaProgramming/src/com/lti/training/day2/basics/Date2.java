package com.lti.training.day2.basics;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Date2 
{
public static void main(String[] args) 
{
	String a ="yyyy/MM/dd";
	Date d= new Date();
	SimpleDateFormat d1= new SimpleDateFormat(a);
	SimpleDateFormat d2= new SimpleDateFormat("hh:mm:ss");
	
	String b=d1.format(d);
	String b2=d2.format(d);
	
	System.out.println(b);
	System.out.println(b2);
	
	int dd=11;
	int MM=07;
	int yyyy=1996;

	Calendar c=Calendar.getInstance();
	c.set(yyyy,MM-1,dd);
	int c3=c.get(Calendar.DAY_OF_WEEK);
	System.out.println(c3);
	
	
	
	
}
}
