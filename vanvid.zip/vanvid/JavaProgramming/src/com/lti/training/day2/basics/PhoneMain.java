package com.lti.training.day2.basics;

import java.util.Scanner;

public class PhoneMain 
{
public static void main(String[] args)
{
	PhoneBook pb=new PhoneBook(10);
	
	Contact c1= new Contact("A","123","abc@gmail.com","01-01-89");

	Contact c2= new Contact("b","124","mno@gmail.com","03-01-89");
	Contact c3= new Contact("c","125","xyz@gmail.com","09-01-89");
	pb.add(c1);
	pb.add(c2);
	pb.add(c3);
	pb.display();
Contact search=	pb.searchByName("b");
if(search!=null)
{
	System.out.println("contact found");
	System.out.println("name"+search.getName()+"\t"+"email"+search.getEmail()+"\t"+"phno"+search.getDob());
}
else
{
	System.out.println("contact not found");
}
}
}
