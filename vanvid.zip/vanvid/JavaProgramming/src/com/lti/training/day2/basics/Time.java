package com.lti.training.day2.basics;

import java.util.Calendar;
import java.util.TimeZone;

public class Time
{
	public static void main(String[] args) 
	{
		Calendar c1=Calendar.getInstance();
		c1.setTimeZone(TimeZone.getTimeZone("America/New_York"));
		System.out.println();
	System.out.println("tym in newyork:"+ c1.get(Calendar.HOUR_OF_DAY ) +":"+ c1.get (Calendar.MINUTE)+":"+ c1.get(Calendar.SECOND));
		
	}

}