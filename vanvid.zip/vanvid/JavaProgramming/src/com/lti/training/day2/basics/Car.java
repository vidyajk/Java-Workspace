package com.lti.training.day2.basics;

public class Car {
	
	//----------------------------------data memebers--------------------------//
private String model;
private  String year;
private double price;

//--------------------------------------constructors----------------------------//
public Car(String model, String year, double price) {
	super();
	this.model = model;
	this.year = year;
	this.price = price;
	
}
//-------------------------------getters and setter----------------//

public String getModel() {
	return model;
}

public void setModel(String model) {
	this.model = model;
}

public String getYear() {
	return year;
}

public void setYear(String year) {
	this.year = year;
}

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}    

		
		
		
	}


