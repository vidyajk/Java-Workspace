package com.lti.training.day2.basics;

import java.util.Date;

public class TestCar 
{
public static void main(String[] args) 
{
	//----------to create an object--------------//
	Car c1=new Car("maruthi 800","1996", 40000);
	Date d=new Date();
	System.out.println(d.getHours()+ ":" +d.getMinutes()+":"+d.getSeconds());
	System.out.println("name of the car:"+c1.getModel()+"\nprice of the car:"+c1.getPrice()+"\nyear of manufacture:"+c1.getYear());

	
	Runtime r=Runtime.getRuntime();
long total=r.totalMemory()/1024/1024;
long free=r.freeMemory()/1024/1024;
long max=r.maxMemory()/1024/1024;
System.out.println("tot mem allocate"+r.totalMemory());
System.out.println("tot mem allocate:"+total+"mb approx");
System.out.println("free:"+free);
System.out.println("max:"+max);

}  
}
 