package com.lti.training.day2.basics;

public class Calculator2 
{
	public static void mul(int x,int y)
	{
		System.out.println(x*y);
	}
	public static void div(int x,int y)
	{
		System.out.println(x/y);
	}
	public static void main(String[] args)
	{
		Calculator2.mul(67, 78);
		Calculator2.div(64,8);
	}
	
}
 