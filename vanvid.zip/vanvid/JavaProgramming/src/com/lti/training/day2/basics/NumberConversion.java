package com.lti.training.day2.basics;

import java.util.Scanner;

public class NumberConversion
{

public static void main(String[] args) {
	

Scanner sc=new Scanner(System.in); 
System.out.println("enter the no");
int n=sc.nextInt();
System.out.println("binary of no n"+Integer.toBinaryString(n));
System.out.println("octal of n"+Integer.toOctalString(n));
System.out.println("hexadecimal of no"+Integer.toHexString(n));
	
}
}
