package com.lti.training.day7.jdbc;

import java.util.List;

import com.lti.training.day6.Serialization.Emp;

public class EmpMain {

	public static void main(String[] args) {
		EmployeeDao empd = new EmployeeDao();
		try
		{
			List<Emp> list =empd.fetchAll();
			for(Emp emp1 : list)
			{
				System.out.println(emp1.getEmpno());
				System.out.println("\t"+emp1.getName());
				System.out.println("\t"+emp1.getSalary());
			}
			
			
		}
		catch(DataAccessException e) {
			e.printStackTrace();
		}
		Emp emp1 = new Emp();
		emp1.setEmpno(10);
		emp1.setName("abc");
		emp1.setSalary(100);
		
		emp1.setEmpno(20);
		emp1.setName("bcd");
		emp1.setSalary(2000);
		
		
		
		try
		{
			empd.insert(emp1);
		
		}
		catch(DataAccessException e)
		{
			e.printStackTrace();
		}
		
		
	}
}
