package com.lti.training.day7.jdbc;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBInfo {

public static void main(String[] args) {
	
	
	Connection conn = null;
	try {
   // step1  load JDBC DRIVER
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
   //step2  try connecting database
		String url = " jdbc:oracle:thin:@localhost:1521:xe";
		String user = "hr";
		String pass ="hr";
		conn = DriverManager.getConnection(url, user,pass);
		
	// trying to print some details abt DB we r connecting to!!!
		DatabaseMetaData dbms = conn.getMetaData();
		System.out.println("DB Name " + dbms.getDatabaseProductName());
		System.out.println("DB Version " + dbms.getDatabaseProductVersion());
	}
	
	catch(ClassNotFoundException cnfe) {
		System.out.println("check for driver jar in class path");
	}
	
	catch(SQLException sqle) {
		
		sqle.printStackTrace();
	}
	
	finally {
		
		try {conn.close();}  catch(Exception ignored)  {}
		
	}
}
}
