package newfolder;

public class C  {
public static void main(String[] args) {
	A a = new B();
	B b = new A();
	a.display();
}
}
