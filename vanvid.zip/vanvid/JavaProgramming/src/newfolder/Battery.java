package newfolder;

public class Battery implements Cloneable
{
	private static int seq=1;
	private int bnum;
	private String name;
	public Battery() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		
		return super.clone();
	}

	@Override
	public String toString() 
	{
		return "Battery [bnum=" + bnum + "]";
	}


	public int getBnum() {
		return bnum;
	}
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Battery(String name)
	{
		this.name = name;
		this.bnum=seq++;
	}
	
	

}

