package newfolder;

public class B extends A
{
static void display()
{
	System.out.println("child called");

}
}
