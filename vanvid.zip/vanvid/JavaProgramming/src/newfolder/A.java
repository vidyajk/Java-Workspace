package newfolder;

public class A
{
 void display()
{
	System.out.println("parent called");
}
}

