package newfolder;

public class Inheritence {

}
