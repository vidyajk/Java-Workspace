package newfolder;

public class TestToy 
{
public static void main(String[] args) throws CloneNotSupportedException 
{
	Toy t1 = new Toy("RC Car",6);
	t1.addBattery("sony");
	t1.addBattery("duracell");
	t1.addBattery("everyday");
	t1.addBattery("sony");
	t1.addBattery("duracell");
	t1.addBattery("everyday");
Toy t2= (Toy) t1.clone();
 System.out.println(t1);
 System.out.println(t2);

}
}
