package com.LTI.training.service;

import java.util.HashMap;
import java.util.Map;


public class InMemoryUserService 
{

	
		private Map<String , String > users;

		public InMemoryUserService()
		{
	       users = new HashMap<>();
	       users.put("vid", "123");
	       users.put("van", "414");
	       users.put("asm", "897");
	       users.put("gty", "768");
		}	
		public boolean isValidUser(String username, String password)
		{
		if(users.containsKey(username))
		{
			String pwd = users.get(username);
			if(pwd.equals(password))
				return true;
		}
		return false;
		}
			
		
	
			
		
	}




