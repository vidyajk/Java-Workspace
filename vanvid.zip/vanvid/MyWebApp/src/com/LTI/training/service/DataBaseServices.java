package com.LTI.training.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.annotation.WebServlet;

public class DataBaseServices {
   public boolean isValidUser(String username, String password) {
	
	Connection conn = null;
    PreparedStatement pstmt =null;
	ResultSet rs= null;
	
	System.out.println("username"+username+"password"+password);
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
		String sql = "select active from USER1 where username=? and password=?";
		pstmt= conn.prepareStatement(sql);
		pstmt.setString(1, username);
        pstmt.setString(2, password);		
        rs = pstmt.executeQuery();
	   
        if(rs!=null && rs.next()) {
        String active = rs.getString("active");
        System.out.println(active);
        if(active.trim().equals("y")) {
        	return true;
        }
        }
        return false;
	}
	catch(Exception e)
	{
		e.printStackTrace();
		return false;
	}
	finally {
		try {rs.close();}catch(Exception e) {}
		try {pstmt.close(); } catch(Exception e) {}
		try {conn.close();}catch(Exception e) {}
	}

}


}


