package com.LTI.training.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServlet;



public class RegistrationPage 
{
	Connection conn = null;
	PreparedStatement pstmt = null;
	try	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection	conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
	   pstmt = conn.prepareStatement("insert into user2 values(?,?,?,?,?)");
	   pstmt.setString(1, user2.getfname());
	   pstmt.setString(2,user2.getlname());
	   pstmt.setString(3, user2.getaddress());
	   pstmt.setString(4, user2.getemail());
	   pstmt.setString(5, user2.getpassword());
   	   pstmt.executeUpdate();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	finally
	{
		try {pstmt.close();}catch(Exception e) { } 
		try {conn.close();}catch(Exception e) {}
	}
}


}
