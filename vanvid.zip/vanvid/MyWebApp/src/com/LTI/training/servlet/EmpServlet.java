package com.LTI.training.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.training.day6.Serialization.Emp;
import com.lti.training.day7.jdbc.DataAccessException;

/**
 * Servlet implementation class EmpServlet
 */
@WebServlet("/EmpServlet")
public class EmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection conn = null;
		PreparedStatement pstmt = null;//precompiled sql statements
		ResultSet rs = null;
		
		try	{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
			pstmt = conn.prepareStatement("insert into emp1 values(?,?,?)");
			pstmt.setInt(1, emp.getEmpno());
		 pstmt.setString(2, emp1.getName());
		 pstmt.setDouble(3, emp1.getSalary());
		pstmt.executeUpdate();
		
		}
		catch(Exception e) {
			throw new DataAccessException("problem while inserting employee data",e);
		}
		finally
		{
			try {pstmt.close();}catch(Exception e) { } 
			try {conn.close();}catch(Exception e) {}
		}
	}
	public List<Emp> fetchAll() throws  DataAccessException{
		
		Connection conn =null;
		PreparedStatement pstmt =null;
		ResultSet rs= null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
			pstmt = conn.prepareStatement("select * from emp1");
			rs = pstmt.executeQuery();
			
			List<Emp> list =new ArrayList<>();
			while(rs.next()) {
				Emp emp1 =new Emp();
				emp1.setEmpno(rs.getInt("empno"));
				emp1.setName(rs.getString("name"));
				emp1.setSalary(rs.getDouble("salary"));
				list.add(emp1);
			}
			return list;
		}
	
	catch(ClassNotFoundException  | SQLException e) {
		throw new DataAccessException("prob fetching emp data",e);
		
	}
		finally {
			try { rs.close();} catch(Exception e) {}
			try {pstmt.close();} catch(Exception e) {}
			try { conn.close();} catch(Exception e) {}
		
		
		}
	}
	}


			
	
	}


}
