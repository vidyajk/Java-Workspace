package com.LTI.training.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.LTI.training.service.DataBaseServices;
import com.LTI.training.service.InMemoryUserService;
import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/Login.php")
public class LoginServlet extends HttpServlet {


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
          //collecting the request /from data
		String  username = request.getParameter("username");
		String  password = request.getParameter("password");
		
		//checking if username/ password is valid
		
//		InMemoryUserService userservice = new InMemoryUserService();
		DataBaseServices userservice = new DataBaseServices();
		boolean isValid = userservice.isValidUser(username, password);
		System.out.println(isValid);
		if(isValid)
		{
			String rememberme = request.getParameter("rememberme");


			if(rememberme !=null && rememberme.equals("yes")) {
				Cookie c1 =new Cookie("uname",username);
				Cookie c2 =new Cookie("upass",password);
				c1.setMaxAge(60 * 60 * 24);
				c2.setMaxAge(60 * 60 * 24);
				response.addCookie(c1);
				response.addCookie(c2);
		//	String un = Base64.getEncoder().encode("rememberme".getBytes("utf-8"));
			//	System.out.println("encodedBytes " + new String(encodedBytes));
			

			}
			response.sendRedirect("welcome.html");
					
		}
		else
		{
			response.sendRedirect("login page.html");
		}
	}

}
