package com.LTI.training.servlet;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CaptchaServlet
 */
@WebServlet("/Captcha.jpeg")
public class CaptchaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	     response.setContentType("image/jpeg"); //MIME
	     ServletOutputStream out =response.getOutputStream();
	     
	     String str ="abcdefghijklamnopqrstuvwxyzaSADFGHJKLOOPABCDEFGHIJKLMNOPQRSTUVWXYZM12345678098765JHNBFGV";
	     
	     String captchaText = "";
	     for (int i = 0; i < 4; i++) {
	    	 int rno = (int ) (Math.random() * str.length());
	    	 captchaText += str.charAt(rno);		 
	     } 
	     
	     //code to generate the image
	     BufferedImage img = new BufferedImage(100,100,BufferedImage.TYPE_INT_RGB);
	     Graphics g = img.getGraphics();

	     g.setColor(Color.PINK);
	     g.fillRect(0, 0, 100, 100);
	     g.setColor(Color.BLACK);
	     g.setFont(new Font("Harrington", Font.BOLD,28));
	     g.drawString(captchaText,15,50);
	     
	     ImageIO.write(img, "jpeg", out);
	     
	}

}
