package com.lti.training.onlineExamination.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.omg.CORBA.PRIVATE_MEMBER;

import com.lti.training.onlineExamination.QuestionBankLoader;
import com.lti.training.onlineExamination.Questions;

/**
 * Servlet implementation class LoadQuestionServlet
 */
@WebServlet("/LoadQuestionServlet")
public class LoadQuestionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		QuestionBankLoader loader = new 	QuestionBankLoader();
		List<Questions>  questions  = loader.loadQuestionsOnJava();
		HttpSession session = request.getSession();
		//checking if the questiono is already stored in the session
		Integer questionNo = (Integer) session.getAttribute("qNo");
		if(questionNo == null)//if not
			questionNo = 0;//start from 0
		
		else if(++questionNo == questions.size()) {
	response.sendRedirect("displayScore.jsp");
		return;
	}
			
		session.setAttribute("qNo", questionNo);
		Questions question = questions.get(questionNo);
		session.setAttribute("currentQs", question);
		
		response.sendRedirect("showQuestion.jsp");
		
	}

}
