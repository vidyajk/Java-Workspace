package com.lti.training.onlineExamination;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class QuestionBankLoader
{
	private QuestionBank questionBank;
	
	
public QuestionBankLoader() {
	questionBank = new QuestionBank();
	
}

public List<Questions> loadQuestionsOnJava()
{
	
	questionBank.addNewSubject("JAVA");
	Questions q = new Questions();
	/*q.setQuestion("what is class");
	List<Option> options = new ArrayList<>();
	Option o1 = new Option("class is a template", true);
	Option o2 = new Option("class is a classroom",false);
	Option o3 = new Option("class is a datatype",false);
	Option o4 = new Option("class is class",false);
	options.add(o1);
	options.add(o2);
	options.add(o3);
	options.add(o4);
	q.setOptions(options);
	questionBank.addNewQuestion("JAVA", q);
	
	q.setQuestion("what is Object");
	List<Option> options1 = new ArrayList<>();
	Option o5 = new Option("Object is a instance of class", true);
	Option o6 = new Option("obj is a classroom",false);
	Option o7 = new Option("obj is a datatype",false);
	Option o8 = new Option("obj is class",false);
	options1.add(o5);
	options1.add(o6);
	options1.add(o7);
	options1.add(o8);
	q.setOptions(options1);
	questionBank.addNewQuestion("JAVA", q);
	
	q.setQuestion("what is G1?");
	List<Option> options2 = new ArrayList<>();
	Option o9 = new Option("G1 is garbage collector", true);
	Option o10 = new Option("G1 is a classroom",false);
	Option o11 = new Option("G1 is a datatype",false);
	Option o12 = new Option("G1 is class",false);
	options2.add(o9);
	options2.add(o10);
	options2.add(o11);
	options2.add(o12);
	q.setOptions(options2);
	questionBank.addNewQuestion("JAVA", q);*/
	
	q.setQuestion("what is the full form of html??");
	List<Option> option4 = new ArrayList<>();
	Option o17 = new Option("hello to mobile lava",false);
	Option o18 = new Option("higher text mark language",false);
	Option o19 = new Option("hyper Text MarkUp language",true);
	Option o20 = new Option("hi to markup language",false);
	option4.add(o17);
	option4.add(o18);
	option4.add(o19);
	option4.add(o20);
	q.setOptions(option4);
	questionBank.addNewQuestion("JAVA", q);
	
	q = new Questions();
	q.setQuestion("what is g1??");
	List<Option> option5 = new ArrayList<>();
	Option o21 = new Option("g1 is jeevan",false);
	Option o22 = new Option("higher text mark language",false);
	Option o23 = new Option("hyper Text MarkUp language",true);
	Option o24 = new Option("hi to markup language",false);
	option5.add(o21);
	option5.add(o22);
	option5.add(o23);
	option5.add(o24);
	q.setOptions(option5);
	questionBank.addNewQuestion("JAVA", q);
	
	q = new Questions();
	q.setQuestion("what is class??");
	List<Option> option3 = new ArrayList<>();
	Option o13 = new Option("hello to mobile lava",false);
	Option o14 = new Option("higher text mark language",false);
	Option o15 = new Option("hyper Text MarkUp language",true);
	Option o16 = new Option("hi to markup language",false);
	option3.add(o13);
	option3.add(o14);
	option3.add(o15);
	option3.add(o16);
	q.setOptions(option3);
	questionBank.addNewQuestion("JAVA", q);
	

	return questionBank.getQuestionsFor("JAVA");
}
}
