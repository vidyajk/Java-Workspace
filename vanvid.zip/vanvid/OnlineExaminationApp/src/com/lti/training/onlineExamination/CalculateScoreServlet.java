package com.lti.training.onlineExamination;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class CalculateScoreServlet
 */
@WebServlet("/CalculateScoreServlet")
public class CalculateScoreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		    HttpSession session = request.getSession();
		    Questions q = (Questions) session.getAttribute("currentQs");

		    int selectedOptionNo = Integer.parseInt(request.getParameter("op"));
		   
		   Integer score =(Integer)session.getAttribute("score");
		   if(score == null)
			   score = 0;
		   Option selectedOption = q.getOptions().get(selectedOptionNo);
		   if(selectedOption.isRightAnswer())
			   score++;
		   session.setAttribute("score", score);
		   
		   response.sendRedirect("LoadQuestionServlet");
	}

}
